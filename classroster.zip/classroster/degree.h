#ifndef DEGREE_H
#define DEGREE_H

enum class DegreeProgram {SECURITY, NETWORK, SOFTWARE};

#endif

